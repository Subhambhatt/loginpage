import React, { useState } from "react";
import ReactDOM from "react-dom";
import axios from 'axios';

import "./LoginPage.css";
const LOGIN_URl = "http://localhost:62744/api/user/ValidateUserCredentials"

function LoginPage() {
    // React States
    const [role, setRole] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessages, setErrorMessages] = useState({});
    const [isSubmitted, setIsSubmitted] = useState(false);

    const handleSubmit = async(event) => {
        //Prevent page reload
        event.preventDefault();

        

        // Compare user info
        if(username==='' || password===''){
            setErrorMessages({name:'pass', message:'Username or Password cannot be empty'})
            // alert('Username or Password cannot be empty')
        }
        else{

            const {data} = await axios.post(LOGIN_URl,
                ({ EmailId:username, UserPassword:password }),
                {
                    headers: {'Content-Type':'application/json'}
                }
            )

            if (data) {
                if ((data==='User' || data==='Admin')) {
                    setIsSubmitted(true);
                    setRole(data)
                } else {
                    setErrorMessages({ name: "pass", message: data });
                }
            } else {
                // Username not found
                setErrorMessages({ name: "pass", message: data });
            }
        }
    };

    // Generate JSX code for error message
    const renderErrorMessage = (name) =>
        name === errorMessages.name && (
            <div className="error">{errorMessages.message}</div>
        );

    // JSX code for login form
    const renderForm = (
        <div className="form">
            <form onSubmit={handleSubmit}>
                <div className="input-container">
                    <label>Username </label>
                    <input type="text" name="uname" value={username}
                            onChange={(event) => setUsername(event.target.value)}
                            placeholder="Enter your Email"  />
                    {/* {renderErrorMessage("uname")} */}
                </div>
                <div className="input-container">
                    <label>Password </label>
                    <input type="password" name="pass" value={password}
                            onChange={(event) => setPassword(event.target.value)} 
                            placeholder="Enter your password"  />
                    {renderErrorMessage("pass")}
                </div>
                <div className="button-container">
                    <input type="submit" className="submit-login" />
                </div>
                <div className="footer-text">
                    <p>New user? Sign-Up <a href="#">here</a></p>
                </div>
            </form>
        </div>
    );

    return (
        <>
            <div className="login-page">
                <p style={{color:'white',fontSize:'50px'}}>Group4 Residency</p>
                <div className="login-form">
                    <div className="title">Sign In</div>
                    {isSubmitted ? <div>Successfully logged in as {role}</div> : renderForm}
                </div>
            </div>
        </>
    );
}

export default LoginPage;