import React from 'react';
import './App.css';
// import Login from './pages/login';
import LoginPage from './pages/LoginPage';

function App() {
  return (
    <div className="App">
      {/* <Login></Login> */}
      <LoginPage></LoginPage>
    </div>
  );
}

export default App;
