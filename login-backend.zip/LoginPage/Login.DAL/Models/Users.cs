﻿using System;
using System.Collections.Generic;

namespace Login.DAL.Models
{
    public partial class Users
    {
        public string EmailId { get; set; }
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }

        public virtual Roles Role { get; set; }
    }
}
