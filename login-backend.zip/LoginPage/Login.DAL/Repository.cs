﻿using Login.DAL.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Login.DAL
{
    public class Repository
    {
        CustomerDBContext context;
        public Repository()
        {
            context = new CustomerDBContext();
        }

        public string ValidateLoginUsingLinq(string emailId, string password)
        {
            string roleName = "";
            try
            {
                var objUser = (from usr in context.Users
                               where usr.EmailId == emailId && usr.UserPassword == password
                               select usr.Role).FirstOrDefault<Roles>();

                if (objUser != null)
                {
                    roleName = objUser.RoleName;
                }
                else
                {
                    roleName = "Invalid credentials";
                }
            }
            catch (Exception)
            {
                roleName = "Invalid credentials";
            }
            return roleName;
        }

       
    }
}
