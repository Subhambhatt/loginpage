﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Login.DAL;
using Login.Service.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Login.Service.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : Controller
    {
        Repository repository;
        public UserController()
        {
            repository = new Repository();
        }

        [HttpPost]
        public JsonResult ValidateUserCredentials(User userObj)
        {
            string roleName = "";
            try
            {
                roleName = repository.ValidateLoginUsingLinq(userObj.EmailId, userObj.UserPassword);
               
            }
            catch (Exception)
            {
                roleName = "Invalid credentials";
            }

            return Json(roleName);
        }
    }
}
